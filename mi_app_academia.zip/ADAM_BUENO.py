import sqlite3
import qrcode
import datetime
import os
import threading
import tempfile
from collections import defaultdict
from datetime import timedelta
import pyrebase

from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.spinner import Spinner
from kivy.uix.scrollview import ScrollView
from kivy.uix.image import Image
from kivy.uix.popup import Popup
from kivy.uix.progressbar import ProgressBar
from kivy.uix.checkbox import CheckBox
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.graphics import Color, Rectangle

# =========================
# CONFIGURACIÓN DE COLORES
# =========================
Window.clearcolor = (0.95, 0.95, 0.95, 1)

COLOR_TEXTO = (0, 0, 0, 1)
COLOR_HINT = (0.4, 0.4, 0.4, 1)
COLOR_BOTON_VERDE = (0.2, 0.7, 0.2, 1)
COLOR_BOTON_AZUL = (0.2, 0.5, 0.8, 1)
COLOR_BOTON_ROJO = (0.8, 0.2, 0.2, 1)
COLOR_BOTON_GRIS = (0.5, 0.5, 0.5, 1)
COLOR_BOTON_NARANJA = (0.9, 0.5, 0.1, 1)

# =========================
# CREAR CARPETAS NECESARIAS
# =========================
for folder in ["qrs", "fondo"]:
    if not os.path.exists(folder):
        os.makedirs(folder)

# =========================
# BASE DE DATOS LOCAL (SQLite)
# =========================
conn = sqlite3.connect("academia.db", check_same_thread=False)
cursor = conn.cursor()

cursor.execute("PRAGMA table_info(alumnos)")
columnas = [col[1] for col in cursor.fetchall()]

cursor.execute("""
CREATE TABLE IF NOT EXISTS alumnos(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT,
    edad TEXT,
    telefono TEXT,
    horario TEXT,
    experiencia TEXT,
    escuela TEXT,
    qr TEXT,
    ultimo_pago TEXT,
    tipo_alumno TEXT,
    clases_restantes INTEGER
)
""")

if "tipo_alumno" not in columnas:
    cursor.execute("ALTER TABLE alumnos ADD COLUMN tipo_alumno TEXT DEFAULT 'mensual'")
if "clases_restantes" not in columnas:
    cursor.execute("ALTER TABLE alumnos ADD COLUMN clases_restantes INTEGER DEFAULT 0")
if "foto" in columnas:
    cursor.execute("ALTER TABLE alumnos DROP COLUMN foto")

# Tabla de asistencia local (opcional)
cursor.execute("""
CREATE TABLE IF NOT EXISTS asistencia_local(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    alumno_id INTEGER,
    fecha TEXT,
    horario TEXT,
    presente INTEGER DEFAULT 0,
    FOREIGN KEY(alumno_id) REFERENCES alumnos(id) ON DELETE CASCADE
)
""")

conn.commit()

# =========================
# CONFIGURACIÓN DE FIREBASE
# =========================
firebase_config = {
    "apiKey": "no-necesitas-api-key",
    "authDomain": "adam-pachuca-muay-thai.firebaseapp.com",
    "databaseURL": "https://adam-pachuca-muay-thai-default-rtdb.firebaseio.com/",
    "storageBucket": "adam-pachuca-muay-thai.appspot.com"
}
firebase = pyrebase.initialize_app(firebase_config)
db = firebase.database()
SITE_URL = "https://adam-pachuca-muay-thai.web.app"  # Cambia si tu URL es diferente


# =========================
# FUNCIONES AUXILIARES
# =========================
def mostrar_mensaje(titulo, mensaje):
    popup = Popup(title=titulo,
                  content=Label(text=mensaje, color=COLOR_TEXTO),
                  size_hint=(0.7, 0.3))
    popup.open()


def calcular_adeudo(fecha_pago_str, tipo_alumno, clases_restantes=None):
    if not fecha_pago_str:
        return True
    try:
        fecha_pago = datetime.datetime.strptime(fecha_pago_str, "%Y-%m-%d").date()
        hoy = datetime.date.today()
        if tipo_alumno == "mensual":
            return (hoy - fecha_pago).days > 30
        elif tipo_alumno == "por clase":
            return clases_restantes is None or clases_restantes <= 0
        elif tipo_alumno == "personalizado":
            return (hoy - fecha_pago).days > 30
    except:
        return True
    return False


def sincronizar_alumnos_firebase():
    try:
        cursor.execute("SELECT id, nombre, horario FROM alumnos")
        alumnos = cursor.fetchall()
        for alumno in alumnos:
            alumno_id = str(alumno[0])
            nombre = alumno[1]
            horario = alumno[2] if alumno[2] else "Sin horario"
            db.child("alumnos").child(alumno_id).set({"nombre": nombre, "horario": horario})
        print("Alumnos sincronizados con Firebase")
    except Exception as e:
        print("Error sincronizando:", e)


# =========================
# APP PRINCIPAL
# =========================
class AcademiaApp(App):

    def build(self):
        self.title = "Academia Adam - Gestión de Alumnos + Asistencia Web"

        root_layout = BoxLayout(orientation="vertical", padding=10, spacing=10)
        scroll = ScrollView()
        self.main_layout = BoxLayout(orientation="vertical", size_hint_y=None, spacing=10)
        self.main_layout.bind(minimum_height=self.main_layout.setter("height"))
        scroll.add_widget(self.main_layout)
        root_layout.add_widget(scroll)

        # ----- CABECERA -----
        cabecera = BoxLayout(size_hint_y=None, height=120)
        base_dir = os.path.dirname(os.path.abspath(__file__))
        ruta_adam = os.path.join(base_dir, "fondo", "adam.png")
        ruta_blanco = os.path.join(base_dir, "fondo", "logo blanco.png")

        if os.path.exists(ruta_adam):
            logo_izq = Image(source=ruta_adam, allow_stretch=True, size_hint_x=0.3)
        else:
            logo_izq = Label(text="ADAM", font_size=32, bold=True, color=(0.2, 0.2, 0.2, 1), size_hint_x=0.3)

        titulo_central = Label(text="ADAM PACHUCA\nTHAI BOXING SPORT",
                               font_size=20, bold=True, color=(0, 0, 0, 1),
                               halign='center', valign='middle', size_hint_x=0.4)
        titulo_central.bind(size=titulo_central.setter('text_size'))

        if os.path.exists(ruta_blanco):
            logo_der = Image(source=ruta_blanco, allow_stretch=True, size_hint_x=0.3)
        else:
            logo_der = Label(text="MUAY THAI", font_size=24, bold=True, color=(0.5, 0.2, 0.2, 1), size_hint_x=0.3)

        cabecera.add_widget(logo_izq)
        cabecera.add_widget(titulo_central)
        cabecera.add_widget(logo_der)
        self.main_layout.add_widget(cabecera)

        # ----- INFORMACIÓN WEB -----
        info_web = Label(text=f"🌐 QR Único para alumnos: {SITE_URL}",
                         size_hint_y=None, height=40, color=(0.2, 0.2, 0.8, 1), font_size=12)
        self.main_layout.add_widget(info_web)

        # ----- CONTADOR -----
        self.total = Label(text="Total alumnos: 0", size_hint_y=None, height=40,
                           font_size=20, bold=True, color=COLOR_TEXTO)
        self.main_layout.add_widget(self.total)

        # ----- FORMULARIO -----
        form_grid = GridLayout(cols=2, spacing=15, size_hint_y=None, padding=10)
        form_grid.bind(minimum_height=form_grid.setter("height"))

        self.nombre = TextInput(hint_text="Nombre *", multiline=False,
                                background_color=(1, 1, 1, 1), foreground_color=COLOR_TEXTO,
                                hint_text_color=COLOR_HINT, size_hint_y=None, height=40)
        self.edad = TextInput(hint_text="Edad", multiline=False,
                              background_color=(1, 1, 1, 1), foreground_color=COLOR_TEXTO,
                              hint_text_color=COLOR_HINT, size_hint_y=None, height=40)
        self.telefono = TextInput(hint_text="Teléfono", multiline=False,
                                  background_color=(1, 1, 1, 1), foreground_color=COLOR_TEXTO,
                                  hint_text_color=COLOR_HINT, size_hint_y=None, height=40)
        self.horario = TextInput(hint_text="Horario (ej: 9am, 11am, 5pm)", multiline=False,
                                 background_color=(1, 1, 1, 1), foreground_color=COLOR_TEXTO,
                                 hint_text_color=COLOR_HINT, size_hint_y=None, height=40)
        self.exp = TextInput(hint_text="¿Ha practicado Muay Thai?", multiline=False,
                             background_color=(1, 1, 1, 1), foreground_color=COLOR_TEXTO,
                             hint_text_color=COLOR_HINT, size_hint_y=None, height=40)
        self.escuela = TextInput(hint_text="Escuela anterior", multiline=False,
                                 background_color=(1, 1, 1, 1), foreground_color=COLOR_TEXTO,
                                 hint_text_color=COLOR_HINT, size_hint_y=None, height=40)

        self.tipo_alumno = Spinner(text="mensual", values=("mensual", "por clase", "personalizado"),
                                   size_hint_y=None, height=40, background_color=(1, 1, 1, 1),
                                   color=COLOR_TEXTO)
        self.clases_restantes = TextInput(hint_text="Clases restantes (solo por clase)", multiline=False,
                                          background_color=(1, 1, 1, 1), foreground_color=COLOR_TEXTO,
                                          hint_text_color=COLOR_HINT, size_hint_y=None, height=40)

        form_grid.add_widget(self.nombre)
        form_grid.add_widget(self.edad)
        form_grid.add_widget(self.telefono)
        form_grid.add_widget(self.horario)
        form_grid.add_widget(self.exp)
        form_grid.add_widget(self.escuela)
        form_grid.add_widget(Label(text="Tipo de alumno:", size_hint_y=None, height=40, color=COLOR_TEXTO))
        form_grid.add_widget(self.tipo_alumno)
        form_grid.add_widget(Label(text="Clases restantes:", size_hint_y=None, height=40, color=COLOR_TEXTO))
        form_grid.add_widget(self.clases_restantes)

        self.main_layout.add_widget(form_grid)

        # ----- BOTONES -----
        botones = BoxLayout(size_hint_y=None, height=60, spacing=10, orientation='horizontal')
        registrar_btn = Button(text="Registrar alumno", background_color=COLOR_BOTON_VERDE,
                               color=(1, 1, 1, 1), font_size=16)
        registrar_btn.bind(on_press=self.registrar)
        ver_lista_btn = Button(text="📋 Ver lista por horarios", background_color=COLOR_BOTON_AZUL,
                               color=(1, 1, 1, 1), font_size=16)
        ver_lista_btn.bind(on_press=self.mostrar_lista_por_horarios)
        adeudos_btn = Button(text="⚠️ Ver adeudos", background_color=COLOR_BOTON_NARANJA,
                             color=(1, 1, 1, 1), font_size=16)
        adeudos_btn.bind(on_press=self.mostrar_adeudos)
        qr_unico_btn = Button(text="🖨️ QR Único Asistencia", background_color=(0.5, 0.4, 0.7, 1),
                              color=(1, 1, 1, 1), font_size=16)
        qr_unico_btn.bind(on_press=self.mostrar_qr_unico)
        ver_asistencia_web_btn = Button(text="🌐 Ver asistencias web", background_color=(0.2, 0.6, 0.8, 1),
                                        color=(1, 1, 1, 1), font_size=16)
        ver_asistencia_web_btn.bind(on_press=self.ver_asistencia_web)

        botones.add_widget(registrar_btn)
        botones.add_widget(ver_lista_btn)
        botones.add_widget(adeudos_btn)
        botones.add_widget(qr_unico_btn)
        botones.add_widget(ver_asistencia_web_btn)
        self.main_layout.add_widget(botones)

        # ----- QR del último alumno -----
        qr_frame = BoxLayout(size_hint_y=None, height=200, padding=5)
        with qr_frame.canvas.before:
            Color(1, 1, 1, 1)
            self.qr_bg = Rectangle(pos=qr_frame.pos, size=qr_frame.size)
            Color(0.7, 0.7, 0.7, 1)
            self.qr_border = Rectangle(pos=qr_frame.pos, size=qr_frame.size)
        qr_frame.bind(pos=self.update_qr_bg, size=self.update_qr_bg)
        self.qr_img = Image(allow_stretch=True)
        qr_frame.add_widget(self.qr_img)
        self.main_layout.add_widget(qr_frame)

        self.actualizar_contador()
        Clock.schedule_once(lambda dt: sincronizar_alumnos_firebase(), 1)
        return root_layout

    def update_qr_bg(self, instance, value):
        self.qr_bg.pos = instance.pos
        self.qr_bg.size = instance.size
        self.qr_border.pos = instance.pos
        self.qr_border.size = instance.size

    def actualizar_contador(self):
        cursor.execute("SELECT COUNT(*) FROM alumnos")
        count = cursor.fetchone()[0]
        self.total.text = f"Total alumnos: {count}"

    # =========================
    # REGISTRAR ALUMNO
    # =========================
    def registrar(self, instance):
        nombre = self.nombre.text.strip()
        if not nombre:
            mostrar_mensaje("Error", "El nombre es obligatorio")
            return

        tipo = self.tipo_alumno.text
        clases_rest = 0
        if tipo == "por clase":
            try:
                clases_rest = int(self.clases_restantes.text.strip()) if self.clases_restantes.text.strip() else 0
            except:
                clases_rest = 0

        popup_progreso = Popup(title="Registrando",
                               content=ProgressBar(max=100),
                               size_hint=(0.5, 0.3),
                               auto_dismiss=False)
        popup_progreso.open()

        def proceso_registro():
            try:
                timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                codigo = f"{nombre}|{timestamp}"
                qr = qrcode.make(codigo)
                qr_path = f"qrs/{nombre}_qr.png"
                qr.save(qr_path)

                pago = str(datetime.date.today())

                cursor.execute("""
                INSERT INTO alumnos(nombre,edad,telefono,horario,experiencia,escuela,qr,ultimo_pago,tipo_alumno,clases_restantes)
                VALUES(?,?,?,?,?,?,?,?,?,?)
                """, (nombre, self.edad.text, self.telefono.text, self.horario.text,
                      self.exp.text, self.escuela.text, qr_path, pago, tipo, clases_rest))
                conn.commit()
                alumno_id = cursor.lastrowid

                # Sincronizar con Firebase
                horario = self.horario.text.strip() if self.horario.text.strip() else "Sin horario"
                db.child("alumnos").child(str(alumno_id)).set({"nombre": nombre, "horario": horario})

                Clock.schedule_once(lambda dt: self.actualizar_contador(), 0)
                Clock.schedule_once(lambda dt: self.limpiar(), 0)
                Clock.schedule_once(lambda dt: setattr(self.qr_img, 'source', qr_path), 0)
                Clock.schedule_once(lambda dt: mostrar_mensaje("Éxito", f"Alumno {nombre} registrado"), 0)
                Clock.schedule_once(lambda dt: popup_progreso.dismiss(), 0)
            except Exception as e:
                Clock.schedule_once(lambda dt: mostrar_mensaje("Error", f"Problema: {str(e)}"), 0)
                Clock.schedule_once(lambda dt: popup_progreso.dismiss(), 0)

        threading.Thread(target=proceso_registro, daemon=True).start()

    def limpiar(self):
        self.nombre.text = ""
        self.edad.text = ""
        self.telefono.text = ""
        self.horario.text = ""
        self.exp.text = ""
        self.escuela.text = ""
        self.tipo_alumno.text = "mensual"
        self.clases_restantes.text = ""

    # =========================
    # ELIMINAR ALUMNO
    # =========================
    def eliminar_alumno(self, id_alum, nombre, popup_actual=None):
        contenido = BoxLayout(orientation="vertical", spacing=10)
        contenido.add_widget(Label(text=f"¿Eliminar a {nombre} permanentemente?", color=COLOR_TEXTO))
        botones = BoxLayout(size_hint_y=None, height=40, spacing=10)
        si_btn = Button(text="Sí, eliminar", background_color=COLOR_BOTON_ROJO, color=(1, 1, 1, 1))
        no_btn = Button(text="Cancelar")
        popup_confirm = Popup(title="Confirmar eliminación", content=contenido, size_hint=(0.6, 0.3),
                              auto_dismiss=False)

        def eliminar_confirmado(instance):
            cursor.execute("DELETE FROM alumnos WHERE id=?", (id_alum,))
            conn.commit()
            db.child("alumnos").child(str(id_alum)).remove()
            self.actualizar_contador()
            popup_confirm.dismiss()
            if popup_actual:
                popup_actual.dismiss()
            mostrar_mensaje("Eliminado", f"Alumno {nombre} eliminado")

        def cancelar(instance):
            popup_confirm.dismiss()

        si_btn.bind(on_press=eliminar_confirmado)
        no_btn.bind(on_press=cancelar)
        botones.add_widget(si_btn)
        botones.add_widget(no_btn)
        contenido.add_widget(botones)
        popup_confirm.open()

    # =========================
    # LISTA POR HORARIOS
    # =========================
    def mostrar_lista_por_horarios(self, instance):
        cursor.execute("SELECT id, nombre, horario, ultimo_pago, tipo_alumno FROM alumnos ORDER BY horario, nombre")
        datos = cursor.fetchall()
        if not datos:
            mostrar_mensaje("Lista de alumnos", "No hay alumnos registrados aún.")
            return

        grupos = defaultdict(list)
        for id_alum, nombre, horario, pago, tipo in datos:
            horario_key = horario if horario.strip() else "Sin horario"
            grupos[horario_key].append((id_alum, nombre, pago, tipo))

        contenido = BoxLayout(orientation="vertical", spacing=10, padding=10)
        titulo_popup = Label(text="📋 Alumnos por Horario", font_size=20, bold=True, color=COLOR_TEXTO, size_hint_y=None,
                             height=40)
        contenido.add_widget(titulo_popup)

        scroll_lista = ScrollView()
        lista_layout = BoxLayout(orientation="vertical", size_hint_y=None, spacing=15)
        lista_layout.bind(minimum_height=lista_layout.setter("height"))

        for horario, alumnos in sorted(grupos.items()):
            header = Label(text=f"🕒 {horario}", font_size=18, bold=True, color=(0.2, 0.5, 0.8, 1),
                           size_hint_y=None, height=35, halign='left')
            header.bind(size=header.setter('text_size'))
            lista_layout.add_widget(header)
            for id_alum, nombre, pago, tipo in alumnos:
                fila = BoxLayout(size_hint_y=None, height=35, spacing=5)
                texto = Label(text=f"  • {nombre} ({tipo}) - Último pago: {pago}",
                              size_hint_x=0.6, halign='left', color=COLOR_TEXTO)
                texto.bind(size=texto.setter('text_size'))
                eliminar_btn = Button(text="🗑️", size_hint_x=0.15, background_color=COLOR_BOTON_ROJO,
                                      color=(1, 1, 1, 1))
                eliminar_btn.bind(on_press=lambda x, id=id_alum, nom=nombre: self.eliminar_alumno(id, nom, None))
                fila.add_widget(texto)
                fila.add_widget(eliminar_btn)
                lista_layout.add_widget(fila)

        scroll_lista.add_widget(lista_layout)
        contenido.add_widget(scroll_lista)
        cerrar_btn = Button(text="Cerrar", size_hint_y=None, height=40, background_color=COLOR_BOTON_GRIS,
                            color=(1, 1, 1, 1))
        popup = Popup(title="Lista de Alumnos", content=contenido, size_hint=(0.8, 0.8), auto_dismiss=False)
        cerrar_btn.bind(on_press=popup.dismiss)
        contenido.add_widget(cerrar_btn)
        popup.open()

    # =========================
    # ADEUDOS
    # =========================
    def mostrar_adeudos(self, instance):
        cursor.execute("SELECT id, nombre, ultimo_pago, tipo_alumno, clases_restantes FROM alumnos")
        alumnos = cursor.fetchall()
        adeudos = []
        for alumno in alumnos:
            id_alum, nombre, pago, tipo, clases = alumno
            if calcular_adeudo(pago, tipo, clases):
                adeudos.append((id_alum, nombre, pago, tipo, clases))

        if not adeudos:
            mostrar_mensaje("Adeudos", "No hay alumnos con pagos pendientes.")
            return

        contenido = BoxLayout(orientation="vertical", spacing=10, padding=10)
        titulo = Label(text="⚠️ Alumnos con adeudo", font_size=20, bold=True, color=COLOR_BOTON_ROJO, size_hint_y=None,
                       height=40)
        contenido.add_widget(titulo)

        scroll_lista = ScrollView()
        lista_layout = BoxLayout(orientation="vertical", size_hint_y=None, spacing=5)
        lista_layout.bind(minimum_height=lista_layout.setter("height"))

        for id_alum, nombre, pago, tipo, clases in adeudos:
            if tipo == "mensual":
                motivo = f"Último pago: {pago} (más de 30 días)"
            elif tipo == "por clase":
                motivo = f"Clases restantes: {clases} (debe pagar más)"
            else:
                motivo = f"Último pago: {pago} (personalizado)"
            fila = BoxLayout(size_hint_y=None, height=40, spacing=5)
            texto = Label(text=f"{nombre} - {motivo}", size_hint_x=0.5, color=COLOR_TEXTO, halign='left')
            texto.bind(size=texto.setter('text_size'))
            pagar_btn = Button(text="Pagar", size_hint_x=0.2, background_color=COLOR_BOTON_VERDE, color=(1, 1, 1, 1))
            eliminar_btn = Button(text="Eliminar", size_hint_x=0.2, background_color=COLOR_BOTON_ROJO,
                                  color=(1, 1, 1, 1))
            pagar_btn.bind(on_press=lambda x, id=id_alum: self.registrar_pago(id_alum))
            eliminar_btn.bind(on_press=lambda x, id=id_alum, nom=nombre: self.eliminar_alumno(id, nom, None))
            fila.add_widget(texto)
            fila.add_widget(pagar_btn)
            fila.add_widget(eliminar_btn)
            lista_layout.add_widget(fila)

        scroll_lista.add_widget(lista_layout)
        contenido.add_widget(scroll_lista)
        cerrar_btn = Button(text="Cerrar", size_hint_y=None, height=40, background_color=COLOR_BOTON_GRIS,
                            color=(1, 1, 1, 1))
        popup_adeudos = Popup(title="Adeudos", content=contenido, size_hint=(0.8, 0.6), auto_dismiss=False)
        cerrar_btn.bind(on_press=popup_adeudos.dismiss)
        contenido.add_widget(cerrar_btn)
        popup_adeudos.open()

    # =========================
    # REGISTRAR PAGO
    # =========================
    def registrar_pago(self, id_alum):
        fecha = str(datetime.date.today())
        cursor.execute("SELECT tipo_alumno, clases_restantes FROM alumnos WHERE id=?", (id_alum,))
        tipo, clases = cursor.fetchone()
        nuevas_clases = clases
        if tipo == "por clase":
            nuevas_clases += 4
            cursor.execute("UPDATE alumnos SET ultimo_pago=?, clases_restantes=? WHERE id=?",
                           (fecha, nuevas_clases, id_alum))
        else:
            cursor.execute("UPDATE alumnos SET ultimo_pago=? WHERE id=?", (fecha, id_alum))
        conn.commit()
        self.actualizar_contador()
        mostrar_mensaje("Pago registrado",
                        f"Pago registrado. Clases restantes: {nuevas_clases if tipo == 'por clase' else 'N/A'}")

    # =========================
    # QR ÚNICO (CORREGIDO)
    # =========================
    def mostrar_qr_unico(self, instance):
        try:
            # Generar QR temporal como archivo
            temp_file = tempfile.NamedTemporaryFile(suffix='.png', delete=False)
            temp_path = temp_file.name
            temp_file.close()

            qr = qrcode.QRCode(box_size=10, border=4)
            qr.add_data(SITE_URL)
            qr.make(fit=True)
            img = qr.make_image(fill_color="black", back_color="white")
            img.save(temp_path)

            # Cargar imagen en Kivy desde archivo
            img_widget = Image(source=temp_path, allow_stretch=True)

            popup = Popup(title="QR Único para Asistencia - Imprime y pega en la entrada",
                          content=img_widget,
                          size_hint=(0.8, 0.8))
            # Eliminar archivo temporal cuando se cierre el popup
            popup.bind(on_dismiss=lambda x: os.unlink(temp_path))
            popup.open()
        except Exception as e:
            mostrar_mensaje("Error al generar QR", f"Detalle: {str(e)}")

    # =========================
    # VER ASISTENCIA WEB (Firebase)
    # =========================
    def ver_asistencia_web(self, instance):
        hoy = datetime.date.today().isoformat()
        horarios = ["9am", "11am", "5pm", "7pm"]
        contenido = BoxLayout(orientation='vertical', spacing=10, padding=10)
        scroll = ScrollView()
        lista = BoxLayout(orientation='vertical', size_hint_y=None, spacing=15)
        lista.bind(minimum_height=lista.setter('height'))

        for horario in horarios:
            try:
                asistencias_ref = db.child(f"asistencias/{hoy}/{horario}").get()
                asistentes = []
                if asistencias_ref.each():
                    for a in asistencias_ref.each():
                        alumno_id = a.key()
                        datos = a.val()
                        nombre = datos.get('nombre', f"Alumno {alumno_id}")
                        asistentes.append(f"{nombre} (ID:{alumno_id})")
                header = Label(text=f"🕒 {horario} - {len(asistentes)} asistentes (vía web)", bold=True,
                               size_hint_y=None, height=40, color=(0.2, 0.5, 0.8, 1))
                lista.add_widget(header)
                if asistentes:
                    for a in asistentes:
                        lbl = Label(text=f"   • {a}", size_hint_y=None, height=30, halign='left', color=COLOR_TEXTO)
                        lbl.bind(size=lbl.setter('text_size'))
                        lista.add_widget(lbl)
                else:
                    lista.add_widget(
                        Label(text="   (Sin asistencias web)", size_hint_y=None, height=30, color=COLOR_TEXTO))
            except Exception as e:
                lista.add_widget(Label(text=f"Error conectando a Firebase: {e}", color=(1, 0, 0, 1)))

        scroll.add_widget(lista)
        contenido.add_widget(scroll)
        cerrar_btn = Button(text="Cerrar", background_color=COLOR_BOTON_GRIS, color=(1, 1, 1, 1), size_hint_y=None,
                            height=40)
        popup = Popup(title=f"Asistencia Web del {hoy}", content=contenido, size_hint=(0.9, 0.8), auto_dismiss=False)
        cerrar_btn.bind(on_press=popup.dismiss)
        contenido.add_widget(cerrar_btn)
        popup.open()

    def on_stop(self):
        conn.close()


if __name__ == "__main__":
    AcademiaApp().run()